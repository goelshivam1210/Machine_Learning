//=============================================================================
// Copyright © 2017 FLIR Integrated Imaging Solutions, Inc. All Rights Reserved.
//
// This software is the confidential and proprietary information of FLIR
// Integrated Imaging Solutions, Inc. ("Confidential Information"). You
// shall not disclose such Confidential Information and shall use it only in
// accordance with the terms of the license agreement you entered into
// with FLIR Integrated Imaging Solutions, Inc. (FLIR).
//
// FLIR MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF THE
// SOFTWARE, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
// PURPOSE, OR NON-INFRINGEMENT. FLIR SHALL NOT BE LIABLE FOR ANY DAMAGES
// SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR DISTRIBUTING
// THIS SOFTWARE OR ITS DERIVATIVES.
//=============================================================================

#ifndef SPINNAKER_GENAPI_CHUNKADAPTERGEV_H
#define SPINNAKER_GENAPI_CHUNKADAPTERGEV_H

#include "ChunkAdapter.h"

namespace Spinnaker
{
    namespace GenApi
    {
        // Declaration of GigE Vision Chunk message trailer

        // make sure everything is properly packed
#   pragma pack(push, 1)

        /**
        * @brief header of a GVCP request packet
        */
        typedef struct GVCP_CHUNK_TRAILER
        {
            uint32_t ChunkID;
            uint32_t ChunkLength;
        } GVCP_CHUNK_TRAILER;

        // restore the previous packing
#   pragma pack(pop)

        /**
        *  @defgroup SpinnakerGenApiClasses Spinnaker GenApi Classes
        */
        /*@{*/

        /**
        *  @defgroup ChunkAdapterGEV_h ChunkAdapterGEV Class
        */
        /*@{*/

        /**
        * @brief Connects a chunked DCAM buffer to a node map.
        */
        class SPINNAKER_API CChunkAdapterGEV : public  CChunkAdapter
        {

        public:
            /**
            * Constructor.
            */
            CChunkAdapterGEV(INodeMap* pNodeMap = NULL, int64_t MaxChunkCacheSize = -1);

            /**
            * Destructor.
            */
            virtual ~CChunkAdapterGEV();

          /**
            * Checks if a buffer contains chunks in a known format.
            */
            virtual bool CheckBufferLayout(uint8_t *pBuffer, int64_t BufferLength);

          /**
            * Attaches a buffer to the matching ChunkPort.
            */
            virtual void AttachBuffer(uint8_t *pBuffer, int64_t BufferLength, AttachStatistics_t *pAttachStatistics = NULL);
        };

        /*@}*/
        /*@}*/
    }
}

#endif // SPINNAKER_GENAPI_CHUNKADAPTERGEV_H
