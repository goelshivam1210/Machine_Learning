Readme.txt
The version for python is 2.7.12


 For question 9, file dt.py can be used as the code.
(a) It uses libraries, numpy
(b) code is commented well enough for understandability.
(c) output of the code is a decision tree created by the training data and it also prints the testing accuracy on the testing dataset.
(d) There is NO implementation of the pruned version of the tree.
(e) For question number 9(e) and (f) Weka was used to compute the accuracy by changing the dataset to arff format.


