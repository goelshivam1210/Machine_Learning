Readme

The file is named gridworld.py
Python version is 2.7.12

The code implements the given grid world and performs q learning algorithm.
after every terminal state it prints out the q values of the states and their corresponding actions

